package com.example.carbiz.dto;

public record LoginRequest(String username, String password) {}