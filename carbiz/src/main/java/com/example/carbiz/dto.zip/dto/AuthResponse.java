package com.example.carbiz.dto;

public record AuthResponse(String token, String role, String username) {}