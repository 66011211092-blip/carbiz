package com.example.carbiz.service;

import com.example.carbiz.dto.MaintenanceCreateRequest;
import com.example.carbiz.entity.Car;
import com.example.carbiz.entity.Maintenance;
import com.example.carbiz.repository.CarRepository;
import com.example.carbiz.repository.MaintenanceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MaintenanceService {
    private final MaintenanceRepository maintenanceRepository;
    private final CarRepository carRepository;

    public List<Maintenance> getByCar(Long carId) {
        return maintenanceRepository.findByCar_Id(carId);
    }

    public Maintenance add(MaintenanceCreateRequest req) {
        Car car = carRepository.findById(req.carId())
                .orElseThrow(() -> new RuntimeException("Car not found with id: " + req.carId()));

        Maintenance m = Maintenance.builder()
                .car(car)
                .detail(req.detail())
                .date(req.date())
                .cost(req.cost())
                .build();

        return maintenanceRepository.save(m);
    }

    public void delete(Long id) {
        maintenanceRepository.deleteById(id);
    }
}