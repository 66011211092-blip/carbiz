package com.example.carbiz.service;

import com.example.carbiz.dto.SaleCreateRequest;
import com.example.carbiz.entity.Car;
import com.example.carbiz.entity.Customer;
import com.example.carbiz.entity.Sale;
import com.example.carbiz.entity.CarStatus;
import com.example.carbiz.repository.CarRepository;
import com.example.carbiz.repository.CustomerRepository;
import com.example.carbiz.repository.SaleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SaleService {
    private final SaleRepository saleRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;

    public List<Sale> getAll() {
        return saleRepository.findAllWithCar();
    }

    @Transactional
    public Sale create(SaleCreateRequest req) {
        // Validate required fields
        if (req.carId() == null) {
            throw new IllegalArgumentException("Car ID is required");
        }
        if (req.saleDate() == null) {
            throw new IllegalArgumentException("Sale date is required");
        }
        if (req.finalPrice() == null) {
            throw new IllegalArgumentException("Final price is required");
        }

        Car car = carRepository.findById(req.carId())
                .orElseThrow(() -> new RuntimeException("Car not found with id: " + req.carId()));

        // ตรวจสอบว่ารถถูกขายไปแล้วหรือยัง
        if (saleRepository.existsByCarId(car.getId())) {
            throw new RuntimeException("Car already sold");
        }

        Customer customer = null;
        if (req.customerId() != null) {
            customer = customerRepository.findById(req.customerId())
                    .orElseThrow(() -> new RuntimeException("Customer not found with id: " + req.customerId()));
        }

        // สร้าง Sale
        Sale sale = Sale.builder()
                .car(car)
                .customer(customer)
                .customerName(req.customerName())
                .customerPhone(req.customerPhone())
                .saleDate(req.saleDate())
                .finalPrice(req.finalPrice())
                .paymentMethod(req.paymentMethod())
                .build();

        // อัพเดทสถานะรถเป็น SOLD
        car.setStatus(CarStatus.SOLD);
        carRepository.save(car);

        return saleRepository.save(sale);
    }

    // เพิ่ม method อื่นๆ ตามต้องการ
    public List<Sale> getSalesByCustomer(Long customerId) {
        return saleRepository.findByCustomerId(customerId);
    }
}