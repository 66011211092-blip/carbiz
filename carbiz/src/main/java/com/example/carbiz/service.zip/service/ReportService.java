package com.example.carbiz.service;

import com.example.carbiz.entity.Maintenance;
import com.example.carbiz.entity.Sale;
import com.example.carbiz.repository.MaintenanceRepository;
import com.example.carbiz.repository.SaleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ReportService {
    private final SaleRepository saleRepository;
    private final MaintenanceRepository maintenanceRepository;

    public Map<String, Object> salesSummary(LocalDate start, LocalDate end) {
        List<Sale> list = saleRepository.findBySaleDateBetween(start, end);

        DoubleSummaryStatistics stats = list.stream()
                .map(Sale::getFinalPrice)
                .filter(v -> v != null)
                .mapToDouble(BigDecimal::doubleValue) // เปลี่ยนจาก Double::doubleValue
                .summaryStatistics();

        return Map.of(
                "count", list.size(),
                "sum", stats.getSum(),
                "avg", list.isEmpty() ? 0 : stats.getAverage(),
                "min", list.isEmpty() ? 0 : stats.getMin(),
                "max", list.isEmpty() ? 0 : stats.getMax()
        );
    }

    public double totalMaintenanceCostByCar(Long carId) {
        List<Maintenance> list = maintenanceRepository.findByCar_Id(carId);
        return list.stream()
                .map(Maintenance::getCost)
                .filter(v -> v != null)
                .mapToDouble(BigDecimal::doubleValue) // เปลี่ยนจาก Double::doubleValue
                .sum();
    }
}