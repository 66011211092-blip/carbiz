package com.example.carbiz.entity;

public enum Role {
    ADMIN,
    SALES,
    MANAGER,
    MAINTENANCE,
    ACQUISITION,
    ACCOUNTING
}