package com.example.carbiz.entity;

public enum CarStatus {
    RECEIVED,
    INSPECTION,
    MAINTENANCE,
    READY_FOR_SALE,
    RESERVED,
    SOLD
}