package com.example.carbiz.config;

import com.example.carbiz.entity.AppUser;
import com.example.carbiz.entity.Role;
import com.example.carbiz.repository.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SeedUsersConfig {

    @Bean
    CommandLineRunner seedUsers(AppUserRepository repo, PasswordEncoder enc) {
        return args -> {
            System.out.println("🔧 Checking user seeding...");

            try {
                // รอให้ Database พร้อม
                Thread.sleep(3000);

                // ใช้ BCrypt password ที่ถูกต้อง
                String encodedPassword = enc.encode("admin123");
                System.out.println("Encoded password: " + encodedPassword);

                createIfAbsent(repo, enc, "admin", "admin123", Role.ADMIN,
                        "System Admin", "090-000-0000");
                createIfAbsent(repo, enc, "sales", "sales123", Role.SALES,
                        "Sales User", "090-111-1111");
                createIfAbsent(repo, enc, "maint", "maint123", Role.MAINTENANCE,
                        "Maintenance", "090-222-2222");
                createIfAbsent(repo, enc, "manager", "manager123", Role.MANAGER,
                        "Manager User", "090-333-3333");

                System.out.println("✅ User seeding check completed");
            } catch (Exception e) {
                System.err.println("⚠️ User seeding skipped: " + e.getMessage());
                // ไม่ต้องทำอะไร ให้ใช้ data.sql แทน
            }
        };
    }

    private static void createIfAbsent(AppUserRepository repo, PasswordEncoder enc,
                                       String username, String rawPassword, Role role,
                                       String fullName, String contact) {
        try {
            // ตรวจสอบว่ามี user นี้แล้วหรือยัง
            if (repo.findByUsername(username).isPresent()) {
                System.out.println("ℹ️ User already exists: " + username);
                return;
            }

            AppUser u = new AppUser();
            u.setUsername(username);
            u.setPassword(enc.encode(rawPassword));
            u.setRole(role);
            u.setFullName(fullName);
            u.setContact(contact);
            repo.save(u);

            System.out.println("✅ Created user: " + username);
        } catch (Exception e) {
            System.err.println("❌ Failed to create user " + username + ": " + e.getMessage());
            // ข้าม user นี้ไป
        }
    }
}