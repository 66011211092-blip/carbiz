package com.example.carbiz.repository;

import com.example.carbiz.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface SaleRepository extends JpaRepository<Sale, Long> {

    // เพิ่ม method นี้
    boolean existsByCarId(Long carId);

    // เพิ่ม method นี้
    List<Sale> findBySaleDateBetween(LocalDate start, LocalDate end);

    // เพิ่ม method นี้ (ถ้าต้องการหา Sale โดย car)
    Optional<Sale> findByCarId(Long carId);
    List<Sale> findByCustomerId(Long customerId);

    @Query("SELECT s FROM Sale s JOIN FETCH s.car WHERE s.customerName LIKE %:name%")
    List<Sale> findByCustomerNameContaining(@Param("name") String name);

    @Query("SELECT s FROM Sale s JOIN FETCH s.car ORDER BY s.saleDate DESC")
    List<Sale> findAllWithCar();

}