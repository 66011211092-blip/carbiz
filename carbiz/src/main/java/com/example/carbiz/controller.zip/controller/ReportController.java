package com.example.carbiz.controller;

import com.example.carbiz.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {
    private final ReportService reportService;

    @GetMapping("/sales")
    public Map<String,Object> sales(@RequestParam String start, @RequestParam String end) {
        return reportService.salesSummary(LocalDate.parse(start), LocalDate.parse(end));
    }

    @GetMapping("/maintenance/total-by-car/{carId}")
    public Map<String, Object> maintenanceTotal(@PathVariable Long carId) {
        double total = reportService.totalMaintenanceCostByCar(carId);
        return Map.of("carId", carId, "totalMaintenanceCost", total);
    }
}
